from contact import Contact
import numpy as np

class Homework:
    def __init__(self, simulator):
        """
        Caled at the start of the simulation.

        You can use this to set the initial state of the datastructures that you will need.

        The simulator object contains the following attributes:
            - radii: array of shape (N,)
            - positions: array of shape (N, 3)
            - rotations: array of shape (N, 4), storing rotations as quaternions
              (each row contains the scalar first, followed by the
               x, y, and z components).
            - angular_velocities: array of shape (N, 3)
            - velocities: array of shape (N, 3)

        where N is the number of objects being simulated.

        You may use all of these attributes throughout the homework.
        """
        pass

    def object_added(self, simulator, i):
        """
        Called every time an object is added to the simulation.

        This can be used to update the data structures you use, if they change
        significantly when new objects are added to the simulation.

        i is the index of the new object.
        """
        pass

    def find_intersections(self, simulator) -> list[Contact]:
        """
        Return all contacts between objects in the simulation.

        simulator.intersect(i, j) returns:
          - None if the objects don't intersect, or
          - a Contact object if they do. This object contains all information the
            simulator needs to resolve the contact.

        The default implementation works, but is not efficient. You should use a
        spatial datastructure to reduce the computational complexity of this method.
        """
        contacts = []

        for i in range(len(simulator.radii)):
            for j in range(i + 1, len(simulator.radii)):
                contact = simulator.intersect(i, j)
                if contact:
                    contacts.append(contact)

        return contacts
